import{useState} from 'react';
import{View,Text,Button,SafeAreaView} from'react-native';

function App(){
  const [somatorio, setSomatorio] = useState(0);
  const [nome, setNome] = useState('Rafael');
  const somar= ()=> {setSomatorio(somatorio + 1)};

  return(
    <SafeAreaView>
      <View>
        <Text> Clique no botão abaixo: {somatorio} - {nome} </Text>
        
        <Button title="Clique" onPress={somar} />
      </View>
    </SafeAreaView>
  ); 
}

export default App;
